<?php
if(file_exists("./config.php"))
{
 header("Location: tt-rss.php");
}
else{
 header("Location: install");
}
