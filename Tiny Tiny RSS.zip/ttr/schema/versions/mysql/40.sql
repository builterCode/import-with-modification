update ttrss_prefs set short_desc = 'Enable feed icons' where pref_name = 'ENABLE_FEED_ICONS'; 

update ttrss_version set schema_version = 40;
